%% ModelUI Guide
% This guide provides details of the menu options, tab views in the UI and
% information about the outputs of the model.
%%
% The <matlab:xxx_open_manual manual> provides further details of setup and 
% configuration of the model.